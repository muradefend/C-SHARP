﻿using FlyWeight;

FlyWeightFactory flyweightfactory = new FlyWeightFactory();

IFlyWeight flyweightA = flyweightfactory.GetFlyWeight('A');
IFlyWeight flyweightB = flyweightfactory.GetFlyWeight('B');
IFlyWeight flyweightC = flyweightfactory.GetFlyWeight('C');

IFlyWeight flyweightA2 = flyweightfactory.GetFlyWeight('A');
IFlyWeight flyweightC2 = flyweightfactory.GetFlyWeight('C');

flyweightA.Display();
flyweightB.Display();
flyweightC.Display();

flyweightA2.Display();
flyweightC2.Display();  