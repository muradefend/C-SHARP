﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlyWeight
{
    public class FlyWeight : IFlyWeight
    {
        private char symbol;

        public FlyWeight(char symbol)
        {
            this.symbol = symbol;
        }

        public void Display()
        {
            Console.WriteLine(symbol);
        }
    }
}
