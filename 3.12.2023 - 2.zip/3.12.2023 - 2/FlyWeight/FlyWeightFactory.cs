﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlyWeight
{   
    public class FlyWeightFactory
    {
        private Dictionary<char, IFlyWeight> flyweights = new Dictionary<char, IFlyWeight>();

        public IFlyWeight GetFlyWeight(char symbol)
        {
            if(!flyweights.ContainsKey(symbol))
            {
                flyweights[symbol] =new FlyWeight(symbol);
            }

            return flyweights[symbol];
        }
    }
}
