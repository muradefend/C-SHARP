﻿using state;

Context context = new Context(new StateA());

context.Request(); 
context.Request(); 
context.Request();