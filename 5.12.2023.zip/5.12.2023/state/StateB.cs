﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace state
{
    public class StateB : IState
    {
        public void Handle(Context context)
        {
            Console.WriteLine("Changed to a state B");
            context.State = new StateA();
        }
    }
}
