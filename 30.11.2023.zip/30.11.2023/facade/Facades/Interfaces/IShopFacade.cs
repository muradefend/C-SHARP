﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace facade.Facades.Interfaces
{
    public interface IShopFacade
    {
        void MakePhoneOrder(string product);
    }
}
