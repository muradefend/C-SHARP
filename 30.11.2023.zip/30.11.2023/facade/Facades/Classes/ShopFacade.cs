﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using facade.Facades.Interfaces;
using facade.Operations;

namespace facade.Facades.Classes
{
    public class ShopFacade : IShopFacade
    {
        private ProductSelectionService _productSelectionService;
        private AvailabilityCheckService _availabilityCheckService;
        private OrderService _orderService;
        private ConfirmationService _confirmationService;

        public ShopFacade()
        {
            _productSelectionService = new ProductSelectionService();
            _availabilityCheckService = new AvailabilityCheckService();
            _orderService = new OrderService();
            _confirmationService = new ConfirmationService();
        }

        public void MakePhoneOrder(string product)
        {
            Console.WriteLine("Starting the process of ordering your product");


            string selectedProduct = _productSelectionService.SelectProduct(product);


            bool isAvailable = _availabilityCheckService.CheckAvailability(selectedProduct);

            if (isAvailable)
            {
                _orderService.PlaceOrder(selectedProduct);

                _confirmationService.ConfirmOrder();
            }
            else
            {
                Console.WriteLine("We can not finish your order");
            }

            Console.WriteLine("Ordering process finished");
        }
    }

}
