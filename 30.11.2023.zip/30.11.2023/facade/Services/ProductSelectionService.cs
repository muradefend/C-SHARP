﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace facade.Operations
{
    public class ProductSelectionService
    {
        public string SelectProduct(string product)
        {
            Console.WriteLine($"Choosen product: {product}");
            return product;
        }
    }
}
