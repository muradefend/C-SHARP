﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace facade.Operations
{
    public class AvailabilityCheckService
    {
        public bool CheckAvailability(string product)
        {
            Console.WriteLine($"Checking availability of product: {product}");
            return true;
        }
    }
}
