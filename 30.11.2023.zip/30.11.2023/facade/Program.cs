﻿using facade;
using facade.Facades.Classes;
using facade.Facades.Interfaces;

IShopFacade shopFacade = new ShopFacade();

shopFacade.MakePhoneOrder("Ps5");