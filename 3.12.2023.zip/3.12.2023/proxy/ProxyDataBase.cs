﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proxy
{
    public class ProxyDataBase : IDataBase
    {
        private DataBase _database;
        private List<string> data_with_cash;

        public ProxyDataBase()
        {
            Console.WriteLine("Proxy DataBase created");
        }

        public List<string> GetData()
        {
            if(_database == null)
            {
                _database = new DataBase();
                data_with_cash = _database.GetData();
            }
            Console.WriteLine("Proxy returned data with cash");
            return data_with_cash;
        }
    }
}
