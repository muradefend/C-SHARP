﻿using proxy;

IDataBase proxydatabase = new ProxyDataBase();
List<string> data = proxydatabase.GetData();

List<string> data_with_cash = proxydatabase.GetData();

