﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proxy
{
    public class DataBase : IDataBase
    {
        private List<string> data;

        public DataBase()
        {
            data = new List<string> { "Data1", "Data2", "Data3" };
            Console.WriteLine("Data Base downoalded");
        }

        public List<string> GetData()
        {
            return data;
        }
    }
}
